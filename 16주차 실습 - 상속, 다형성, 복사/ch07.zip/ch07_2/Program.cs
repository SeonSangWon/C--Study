﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ch07_2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Dog> Dogs = new List<Dog>() { new Dog(), new Dog(), new Dog() };
            List<Cat> Cats = new List<Cat>() { new Cat(), new Cat(), new Cat() };

            foreach (var items in Dogs)
            {
                items.Eat();
                items.Sleep();
                items.Bark();
            }

            Console.WriteLine();

            foreach (var items in Cats)
            {
                items.Eat();
                items.Sleep();
                items.Bark();
            }
        }
    }
}
