﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ch07_2
{
    //Animal Class를 상속받는다.
    class Cat : Animal
    {
        public void Bark() { Console.WriteLine("냥냥 짓습니다."); }
    }
}