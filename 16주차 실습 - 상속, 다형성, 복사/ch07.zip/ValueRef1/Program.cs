﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueRef1
{
    class Program
    {
        class Test
        {
            public int value;
        }

        static void Change(Test intput)
        {
            intput.value = 20;
        }

        static void Main(string[] args)
        {
            Test test = new Test();
            test.value = 30;
            Change(test);

            Console.WriteLine(test.value);
        }
    }
}
