﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //버튼 클릭 시, 이벤트 처리
        private void Login_btn_Click(object sender, EventArgs e)
        {
            if (ID_text.Text == "yuhan02" && PW_text.Text == "1234")
            {
                //해당 폼을 숨기기
                this.Hide();

                MainForm main = new MainForm();
                main.ShowDialog();

                this.Close();
            }
            else
            {
                MessageBox.Show("아이디와 비밀번호를 확인해주세요.");
            }
        }

        private int elapsedTime = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            elapsedTime++;
            Timer_text.Text = elapsedTime + "초 경과";
        }
    }
}
